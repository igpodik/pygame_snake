import pygame

from Game_script import Game
from Board_script import Board
from Object_script import Objects
from Hero_script import Snake
from Game_state_script import State
from menu import MainMenu
from Music import *
from const import *


def main():
    # запускаем pygame и меняем заголовок окна
    pygame.init()
    pygame.display.set_caption('SNAKE')

    # создаем экран, на котором будут отображаться действия
    screen = pygame.display.set_mode(WINDOW_SIZE)

    # создаем экран для фона
    screen_fon = pygame.Surface(WINDOW_SIZE)

    # создаем экземпляр класса змеи
    snake = Snake()

    # экземпляр класса поля
    board = Board()

    # создаем экземпляр класса объектов
    objects = Objects(snake, screen, board)

    # создаем экземпляр класса игры
    game = Game(snake, objects, screen, board)

    # экземпляр класса состояния игры
    state = State(snake, game)

    # отрисовываем фон
    board.render(screen_fon)

    # выводим историю змеи
    state.start_screen()

    # открываем меню
    main_menu = MainMenu(screen, game, screen_fon, snake)
    main_menu.run()

    # запускаем музыку
    play_music(f'фон {snake.level} уровень')
    pygame.mixer.music.set_volume(snake.voice)

    running = True

    # игровой цикл
    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # если нажали p ставлю на паузу
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                snake.is_paused = not snake.is_paused
                game.switch_pause()

            # если нажали l загружаем сохранение (функция для удобства отладки, должна быть закоменчена)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_l and not snake.is_paused:
                game.load_game()
                board = Board(snake.level)
                board.render(screen_fon)
                play_music(f'фон {snake.level} уровень')
                pygame.mixer.music.set_volume(snake.voice)
                game.render()
                pygame.display.flip()

            # сохранение
            if event.type == pygame.KEYDOWN and event.key == pygame.K_s:
                game.save_game()

            # настройка музыки
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_1:  # если 1, ставим на паузу
                    pygame.mixer.music.pause()
                elif event.key == pygame.K_2:  # если 2, уменьшаем громкость
                    snake.voice -= 0.1
                    pygame.mixer.music.unpause()  # на всякий случай
                    pygame.mixer.music.set_volume(snake.voice)
                elif event.key == pygame.K_4:  # если 4, запускаем музыку на полной громкости
                    snake.voice = 1
                    pygame.mixer.music.unpause()  # на всякий случай
                    pygame.mixer.music.set_volume(snake.voice)
                elif event.key == pygame.K_3:  # если 3, увеличиваем громкость
                    snake.voice += 0.1
                    pygame.mixer.music.unpause()  # на всякий случай
                    pygame.mixer.music.set_volume(snake.voice)

            # если надо обновить уровень
            if snake.update_level:
                snake.update_level = False
                board = Board(snake.level)
                board.render(screen_fon)

            # если игра закончена
            if snake.is_game_over:
                main_menu.is_open = False  # Устанавливаем флаг "главное меню" в False
                main_menu.is_end = True  # Устанавливаем флаг "конец игры" в True
                main_menu.end_of_game()  # Запускаем меню победы или конца игры

            else:
                # обновляем координаты змеи, если это требуется
                game.update_hero(event)

        # рисуем элементы
        if not snake.is_game_over:
            screen.blit(screen_fon, (0, 0))
            game.render()

            # меняем предыдущий экран на только что нарисованный
            pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()

# перед запуском программы введите в cmd
# pip install -r requirements.txt
