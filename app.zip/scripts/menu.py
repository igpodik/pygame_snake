import pygame
import os
from const import *
from Board_script import Board
from Music import *
from Object_script import Objects
from Game_script import Game

import sys


def exit_game():
    pygame.quit()
    sys.exit()


class MainMenu:
    def __init__(self, screen, game, screen_fon, snake):
        self.screen = screen
        self.snake = snake
        self.clock = pygame.time.Clock()
        self.screen_fon = screen_fon
        self.font = pygame.font.Font(None, 40)
        self.menu_items = ["Последнее сохранение", "Новая игра", "Выйти", "Правила"]
        self.end_items = ["Выйти"]
        self.selected_item = 0  # индекс выбранного элемента меню
        self.selected_end_item = 0
        self.is_open = True  # флаг, указывающий, отображается ли меню
        self.is_end = False  # флаг конца игры
        self.game = game

    def handle_button_click(self):
        selected_text = self.end_items[self.selected_end_item]
        if selected_text == "Выйти":
            print('нажали выйти')
            exit_game()  # глобальная функция

    def draw_end_menu(self):
        if self.snake.win:
            fon = pygame.transform.scale(pygame.image.load('../pictures/счастливый конец.jpg'), WINDOW_SIZE)
            self.screen.blit(fon, (0, 0))
            win = pygame.image.load('../pictures/экран победы.png')
            self.screen.blit(win, (600, 200))

        else:
            fon = pygame.transform.scale(pygame.image.load('../pictures/конец.jpg'), WINDOW_SIZE)
            self.screen.blit(fon, (0, 0))
            self.snake.show_text(f'SCORE: {self.snake.score}', (WINDOW_WIDTH // 2 - 90, WINDOW_HEIGHT // 2 + 200),
                                 30, (255, 0, 0), self.screen)

        for i, item in enumerate(self.end_items):
            if i == self.selected_end_item:
                color = (255, 0, 0)  # Красный цвет для выбранного элемента меню
            else:
                color = (255, 255, 255)  # Белый цвет для остальных элементов меню

            text = self.font.render(item, True, color)
            text_rect = text.get_rect()
            text_rect.center = (int(self.screen.get_width() * (5 / 6)), self.screen.get_height() // 1.3 + i * 60)
            self.screen.blit(text, text_rect)

    def draw_menu(self):
        self.screen.fill((0, 0, 0))  # Заливка экрана черным цветом

        for i, item in enumerate(self.menu_items):
            if i == self.selected_item:
                color = (255, 0, 0)  # Красный цвет для выбранного элемента меню
            else:
                color = (255, 255, 255)  # Белый цвет для остальных элементов меню

            text = self.font.render(item, True, color)
            text_rect = text.get_rect()
            text_rect.center = (self.screen.get_width() // 2, self.screen.get_height() // 2 + i * 60)
            self.screen.blit(text, text_rect)

    def select_next_item(self, mod):
        if mod == 0:
            self.selected_item = (self.selected_item + 1) % len(self.menu_items)
        elif mod == 1:
            self.selected_end_item = (self.selected_end_item + 1) % len(self.end_items)

    def select_previous_item(self, mod):
        if mod == 0:
            self.selected_item = (self.selected_item - 1) % len(self.menu_items)
        elif mod == 1:
            self.selected_end_item = (self.selected_end_item - 1) % len(self.end_items)

    def end_of_game(self):
        self.snake.is_game_over = not self.snake.is_game_over
        # запускаем музыку
        play_music('смерть', 1)
        pygame.mixer.music.set_volume(0.3)

        if self.snake.win:
            play_music('концовка')
            pygame.mixer.music.set_volume(0.3)

        self.is_end = True

        while self.is_end:  # Используем self.is_end вместо running
            self.clock.tick(30)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.is_end = False  # Завершаем цикл, если нажата кнопка закрытия окна

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    self.handle_mouse_click(mouse_pos)
                    self.handle_button_click()  # Вызываем обработку нажатия кнопок

            self.draw_end_menu()
            pygame.display.flip()

    def run(self):
        running = True

        # запускаем музыку
        play_music('заставка')
        pygame.mixer.music.set_volume(0.3)

        while running:
            self.clock.tick(30)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        self.select_previous_item(0)
                    elif event.key == pygame.K_DOWN:
                        self.select_next_item(0)
                    elif event.key == pygame.K_RETURN:
                        self.handle_selected_item(0)
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    self.handle_mouse_click(mouse_pos)

            if self.is_open:

                self.draw_menu()
                pygame.display.flip()
            else:
                running = False

    def handle_selected_item(self, mod):
        if mod == 0:
            selected_text = self.menu_items[self.selected_item]
        else:
            selected_text = self.end_items[self.selected_end_item]

        if selected_text == "Последнее сохранение":
            # если файл не существует, то выходим
            if not os.path.isfile(f'{DATA_DIR}/save.dat'):
                print(f"Файл с сохранением не найден")
            else:
                self.load_last_save()
        elif selected_text == "Новая игра":
            self.start_new_game()
        elif selected_text == "Выйти":
            exit_game()
        elif selected_text == "Правила":
            self.show_rules()

    def handle_mouse_click(self, mouse_pos):
        if not self.is_end:
            for i, item_rect in enumerate(self.get_menu_item_rects(mod=0)):
                if item_rect.collidepoint(mouse_pos):
                    self.selected_item = i
                    self.handle_selected_item(mod=0)  # Исправленный вызов функции с передачей параметра mod=0
        else:
            for i, item_rect in enumerate(self.get_menu_item_rects(mod=1)):
                if item_rect.collidepoint(mouse_pos):
                    self.selected_end_item = i
                    self.handle_selected_item(mod=1)  # Исправленный вызов функции с передачей параметра mod=1

    def get_menu_item_rects(self, mod):
        item_rects = []
        iterate_object = self.menu_items if mod == 0 else self.end_items

        for i, item in enumerate(iterate_object):
            text_rendered = self.font.render(item, True, (255, 255, 255))
            text_rect = text_rendered.get_rect()
            text_rect.center = (self.screen.get_width() // 2, self.screen.get_height() // 2 + i * 60)
            item_rects.append(text_rect)
        return item_rects

    def load_last_save(self):
        # Обработка загрузки последнего сохранения
        self.game.load_game()
        self.board = Board(self.snake.level)
        self.board.render(self.screen_fon)
        self.snake.start = False
        play_music(f'фон {self.snake.level} уровень')
        pygame.mixer.music.set_volume(0.5)

        self.is_open = False  # закрыть меню
        print('последнее сохранение')

    def start_new_game(self):
        # Обработка начала новой игры
        self.selected_item = 0
        self.selected_end_item = 0
        self.is_open = False
        self.is_end = False

        self.board = Board()

        # создаем экземпляр класса объектов
        self.objects = Objects(self.snake, self.screen, self.board)

        # создаем экземпляр класса игры
        self.game = Game(self.snake, self.objects, self.screen, self.board)

        # запускаем музыку
        play_music(f'фон {self.snake.level} уровень')
        print('новая игра')

    def show_rules(self):
        # Загрузка правил из файла rules.txt
        with open('rules.txt', 'r', encoding='utf-8') as file:
            rules = file.readlines()
            rules = [line.strip() for line in rules]

        # Отображение правил
        self.screen.fill((0, 0, 0))  # Заливка экрана черным цветом

        font = pygame.font.Font(None, 20)
        y = 50  # Начальная координата Y для отображения правил

        for rule in rules:
            text = font.render(rule, True, (255, 255, 255))
            text_rect = text.get_rect()
            text_rect.center = (self.screen.get_width() // 2, y)
            self.screen.blit(text, text_rect)
            y += 30  # Инкремент координаты Y для следующего правила

        pygame.display.flip()
        self.wait_for_back_button()

    def wait_for_back_button(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
