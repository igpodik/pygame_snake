from Sprite_script import *
from Music import play_music

import pygame
import random
import time


# класс еды и счетчика очков
class Objects:
    def __init__(self, hero, screen, board):
        self.hero = hero
        self.screen = screen
        self.board = board

    # функция рисования здоровья
    def show_health(self, screen, cords):
        triangle_width = 15
        triangle_height = 10
        triangle_color = (255, 0, 0)  # красный цвет
        text_position = cords  # позиция надписи "Очков:"
        triangle_top_left = (
            text_position[0] + 60, text_position[1] + 25)  # верхний левый угол первого треугольника

        for i in range(self.hero.health):
            triangle_top = (triangle_top_left[0] + (i * triangle_width), triangle_top_left[1])
            pygame.draw.polygon(screen, triangle_color,
                                [(triangle_top[0], triangle_top[1] + triangle_height),
                                 (triangle_top[0] + (triangle_width / 2), triangle_top[1]),
                                 (triangle_top[0] + triangle_width, triangle_top[1] + triangle_height)])

    # функция для проверки, сколько объект на экране
    def check_time(self, sprite):
        time_created = sprite.time
        current_time = time.time()

        # Вычисляем время, прошедшее с момента создания еды
        elapsed_time = current_time - time_created

        # Если прошло 5 секунд
        if elapsed_time >= 5:
            return True

        return False

    # проверка, свободна ли клетка
    def check_tile(self, coords):
        x, y = coords
        # Создайте временный спрайт с прямоугольником в нужной позиции
        temp_sprite = pygame.sprite.Sprite()
        temp_sprite.rect = pygame.Rect(x, y, TILE_SIZE, TILE_SIZE)

        # Проверьте наличие пересечения прямоугольников с другими спрайтами
        collisions = pygame.sprite.spritecollide(temp_sprite, all_sprites, False)
        if collisions:
            return True
        else:
            return False

    # функция замены элемента
    def change_element(self, current_sprite=None):
        if current_sprite:
            current_sprite.kill()
        index = random.randint(1, 5)

        # считаем отступ от поля в зависимости от уровня
        barrier = 3 if self.hero.level <= 3 else 15

        # Генерируем случайные координаты
        x = random.randint(barrier + 2, WINDOW_WIDTH // TILE_SIZE - barrier - 1) * TILE_SIZE
        y = random.randint(barrier + 2, WINDOW_HEIGHT // TILE_SIZE - barrier - 1) * TILE_SIZE

        while self.check_tile((x, y)):  # пока клетка занята, генерим новые координаты
            x = random.randint(barrier + 2, WINDOW_WIDTH // TILE_SIZE - barrier - 1) * TILE_SIZE
            y = random.randint(barrier + 2, WINDOW_HEIGHT // TILE_SIZE - barrier - 1) * TILE_SIZE

        num_bonuses = len(luck_sprites) + len(batery_sprites)  # количество активных бустов

        # заменяем активный элемент на случайный из всего множества элементов
        if index == 1:
            BadFood((x, y))
        elif index == 3 and num_bonuses == 0:
            Batery((x, y))
        elif index == 4 and num_bonuses == 0:
            Luck((x, y))
        else:
            GoodFood((x, y))

        return

    # функция увеличения уровня
    def level_up(self):
        # обновляем уровень
        if self.hero.level < 4:
            self.hero.update_level = True
            self.hero.level += 1

            self.hero.voice = 0.3
            play_music(f'фон {self.hero.level} уровень')
            pygame.mixer.music.set_volume(0.5)

            # сбрасываем значения скорости змеи
            self.hero.change_speed(0, 0, True)

            # обновляем очки
            self.hero.score = 0
            self.hero.way = 'u'

            # переносим змейку в середину экрана
            self.hero.x = (WINDOW_WIDTH // TILE_SIZE - 2) // 2
            self.hero.y = (WINDOW_HEIGHT // TILE_SIZE - 2) // 2

            # очищаем все спрайты
            self.hero.snake_list.clear()
            self.hero.head.kill()
            self.hero.tail.kill()
            for i in snake_body_sprites.sprites():
                i.kill()
            for i in all_sprites.sprites():
                i.kill()

            # добавляем в группу спрайтов тела 2 элемента - голову и хвост
            self.hero.snake_list = [[self.hero.x, self.hero.y + 2, self.hero.way],
                                    [self.hero.x, self.hero.y + 1, self.hero.way],
                                    [self.hero.x, self.hero.y, self.hero.way],
                                    [self.hero.x, self.hero.y + 3, self.hero.way]]

            Body((self.hero.x, self.hero.y + 2), self.hero.way, self.hero.score, self.hero.health)
            Body((self.hero.x, self.hero.y + 1), self.hero.way, self.hero.score, self.hero.health)
            self.hero.head = Head((self.hero.x, self.hero.y), self.hero.way, self.hero.score, self.hero.health)
            self.hero.tail = Tail((self.hero.x, self.hero.y + 3), self.hero.way, self.hero.score, self.hero.health)
        elif self.hero.level == 4:
            self.hero.win = True
            self.hero.is_game_over = True

    # функция рисования надписи очков и здоровья
    def print_text(self, screen):
        # задаем координаты надписи
        cords = (7, 7)

        # выводим очки
        self.hero.show_text(f'POINTS: {self.hero.score}', cords, 20, (255, 0, 0), screen)

        # выводим чуть ниже здоровье
        self.show_health(self.screen, cords)

    # функция для отрисовки объектов и счета
    def render(self, screen):
        # выводим очки и здоровье
        self.print_text(screen)

        # если набрали 25 очков - повышаем уровень
        if self.hero.score >= 25:
            self.level_up()

        if self.hero.start:
            # в соответствии с уровнем генерируем еду
            if self.hero.level > 2:  # если уровень > 2, то на экране будет меньше еды
                len_sprites_list = len(active_object_sprites.sprites())
                while len_sprites_list < 2:
                    self.change_element()
                    len_sprites_list += 1

            elif self.hero.level <= 2:
                len_sprites_list = len(active_object_sprites.sprites())
                while len_sprites_list < 4:
                    self.change_element()
                    len_sprites_list += 1

            sprites_list = active_object_sprites.sprites()

            for element in sprites_list:  # проверяем время нахождения на экране
                if self.check_time(element):
                    self.change_element(element)

            pygame.time.delay(self.hero.delay)
