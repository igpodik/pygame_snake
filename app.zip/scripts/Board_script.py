from const import *
from Sprite_script import Field, load_image


# класс клеток для рисования фона
class Board:
    def __init__(self, level=1):
        self.board = []
        # открываем карту уровня
        with open(f'../maps/level_{level}n.txt', 'r') as mapp:
            for line in mapp:
                self.board.append(list(map(int, line.split())))

        self.width = len(self.board[0])
        self.height = len(self.board)
        # айди спрайтов
        self.sprites = {0: "sand", 1: "grace", 2: "sea", 3: "dump_sand"}

    # возвращает тип элемента по координате ячейке
    def get_tile_id(self, cords):
        return self.board[cords[1]][cords[0]]

    # отрисовка экрана
    def render(self, screen):

        # рисуем фон и добавляем спрайты в группу поля
        for i in range(self.width):
            for j in range(self.height):
                if self.get_tile_id((i, j)) != 1:
                    Field((i * TILE_SIZE, j * TILE_SIZE), self.sprites[self.get_tile_id((i, j))])
                image = load_image(self.sprites[self.get_tile_id((i, j))])
                screen.blit(image, (i * TILE_SIZE, j * TILE_SIZE))
