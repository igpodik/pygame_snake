import pygame
from random import randint
import time
import sys
import os

from const import *
from Music import *


def load_image(name, colorkey=None):
    fullname = f'../pictures/{name}.png'

    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)

    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()

    return image


food_sprites = pygame.sprite.Group()
bad_sprites = pygame.sprite.Group()
snake_body_sprites = pygame.sprite.Group()
field_sprites = pygame.sprite.Group()
batery_sprites = pygame.sprite.Group()
luck_sprites = pygame.sprite.Group()
snake_head_sprites = pygame.sprite.Group()
snake_tail_sprites = pygame.sprite.Group()
active_object_sprites = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()


class Body(pygame.sprite.Sprite):
    def __init__(self, coords, way, score, health):
        super().__init__(snake_body_sprites)
        all_sprites.add(self)
        self.image = load_image('snake_body')
        self.rect = self.image.get_rect()
        self.rect.x = coords[0] * TILE_SIZE
        self.rect.y = coords[1] * TILE_SIZE
        self.score = score
        self.health = health
        self.way = way


class Head(Body):
    def __init__(self, rect, way, score, health):
        super().__init__(rect, way, score, health)
        snake_head_sprites.add(self)
        all_sprites.add(self)
        snake_body_sprites.remove(self)

        self.image = load_image(f'snake_head-{self.way}')
        self.speed_boost = False
        self.is_game = True

    def update(self):
        if pygame.sprite.spritecollideany(self, snake_body_sprites):
            print('Game_over, врезался в тело')
            self.is_game = False

        elif pygame.sprite.spritecollideany(self, snake_tail_sprites):
            print('Game_over, съел хвост')
            self.is_game = False

        elif pygame.sprite.spritecollideany(self, field_sprites):
            print('Game_over, напоролся на препятствие')
            self.is_game = False

        elif self.health <= 0:
            print('Game_over, закончилось здроровье')
            self.is_game = False

        if pygame.sprite.spritecollideany(self, food_sprites):
            collide_sprite = pygame.sprite.spritecollideany(self, food_sprites)
            collide_sprite.kill()
            print('good_food_was_eaten')
           # play_effect('укус')
            self.score += 1

        if pygame.sprite.spritecollideany(self, bad_sprites):
            collide_sprite = pygame.sprite.spritecollideany(self, bad_sprites)
            collide_sprite.kill()
            print('bad_food_was_eaten')
           # play_effect('укус')
            self.health -= 1

        if pygame.sprite.spritecollideany(self, batery_sprites):
            collide_sprite = pygame.sprite.spritecollideany(self, batery_sprites)
            collide_sprite.kill()
            self.speed_boost = True
            print('speed_boost active')
           # play_effect('укус')

        if pygame.sprite.spritecollideany(self, luck_sprites):
            collide_sprite = pygame.sprite.spritecollideany(self, luck_sprites)
            collide_sprite.kill()
          #  play_effect('укус')
            index = randint(0, 5)
            chance = randint(0, 4)
            if index == 0:
                self.health += 1
            elif index == 1:
                self.health -= 1
            elif index == 2:
                self.score += 1
            elif index == 3:
                self.score -= 1
            elif index == 4:
                self.speed_boost = not self.speed_boost
            elif index == 5 and chance == 1:
                self.is_game = False
            elif index == 5 and chance == 4:
                self.score += 5

        if self.score < 0:
            self.is_game = False
            print('отрицательное количество очков')


class Tail(Body):
    def __init__(self, coords, way, score, health):
        super().__init__(coords, way, score, health)
        self.image = load_image(f'snake_tail-{self.way}')
        self.c1 = coords[0]
        self.c2 = coords[1]
        snake_tail_sprites.add(self)
        all_sprites.add(self)
        snake_body_sprites.remove(self)

    def update(self):
        self.rect.move_ip(self.c1 * TILE_SIZE, self.c2 * TILE_SIZE)


class Field(pygame.sprite.Sprite):
    def __init__(self, coords, name):
        super().__init__(field_sprites)
        all_sprites.add(self)
        self.image = load_image(name)
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = coords


class BadFood(pygame.sprite.Sprite):
    def __init__(self, coords):
        array = ['бомба', 'винт', 'яд']

        super().__init__(bad_sprites)
        active_object_sprites.add(self)
        all_sprites.add(self)
        picture_name = array[randint(0, 2)]

        self.image = load_image(picture_name)
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = coords
        self.time = time.time()


class GoodFood(pygame.sprite.Sprite):
    def __init__(self, coords):
        array = ['груша', 'яблоко', 'вишня']

        super().__init__(food_sprites)
        active_object_sprites.add(self)
        all_sprites.add(self)
        picture_name = array[randint(0, 2)]

        self.image = load_image(picture_name)
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = coords
        self.time = time.time()


class Batery(pygame.sprite.Sprite):
    def __init__(self, coords):
        super().__init__(batery_sprites)
        active_object_sprites.add(self)
        all_sprites.add(self)
        picture_name = 'батарейка'

        self.image = load_image(picture_name)
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = coords
        self.time = time.time()


class Luck(pygame.sprite.Sprite):
    def __init__(self, coords):
        super().__init__(luck_sprites)
        active_object_sprites.add(self)
        all_sprites.add(self)
        picture_name = 'лакиблок'

        self.image = load_image(picture_name)
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = coords
        self.time = time.time()
