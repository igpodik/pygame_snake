import pygame.mixer as mx
import pygame


# проиграть эффект
def play_effect(name):
    pygame.mixer.music.pause()
    sound = mx.Sound(f'../sounds/{name}.mp3')
    sound.play()


# запустить фоновую музыку
def play_music(name, mod=-1):
    mx.music.load(f'../sounds/{name}.mp3')
    mx.music.play(mod)
