from const import *
from random import randint


with open('../maps/level_4.txt', 'w') as file:
    width = WINDOW_WIDTH // TILE_SIZE
    height = WINDOW_HEIGHT // TILE_SIZE
    mapp = [[1] * width for i in range(height)]

    # обновляем границы поля
    for i in range(width):
        # нижние и верхние
        for j in range(int(height * 0.25) // 2):
            mapp[j][i] = 2
            mapp[height - 1 - j][i] = 2
    for i in range(height):
        # левые и правые
        for j in range(int(width * 0.25) // 2):
            mapp[i][j] = 2
            mapp[i][width - 1 - j] = 2

    # добавляем рандомные лужи
    for i in range(30):
        y = randint(5, 115)
        x = randint(5, 58)
        mapp[x][y] = 2

    # делаем смайл вверху
    for i in range(17, 21):
        for k in range(36, 40):
            mapp[i][k] = 2
        for j in range(56, 60):
            mapp[i][j] = 2

    for i in range(25, 27):
        for k in range(40, 56):
            mapp[i][k] = 2

    for i in range(23, 25):
        for k in range(36, 40):
            mapp[i][k] = 2
        for j in range(56, 60):
            mapp[i][j] = 2

    # делаем смайл внизу
    for i in range(17, 21):
        for k in range(36, 40):
            mapp[i + 28][k + 10] = 2
        for j in range(56, 60):
            mapp[i + 28][j + 10] = 2

    for i in range(25, 27):
        for k in range(40, 56):
            mapp[i + 28][k + 10] = 2

    for i in range(23, 25):
        for k in range(36, 40):
            mapp[i + 28][k + 10] = 2
        for j in range(56, 60):
            mapp[i + 28][j + 10] = 2

    # записываем в файл
    for i in mapp:
        for j in i:
            file.write(str(j))
        file.write('\n')
        print(*i)
    file.write('')


