import pickle
import pygame

from Sprite_script import *


# класс игры
class Game:
    def __init__(self, hero, objects, screen, board):
        self.hero = hero
        self.screen = screen
        self.objects = objects
        self.board = board

    # функция для отрисовки всех объектов
    def render(self):
        # рисую спрайты кроме поля чтоб не грузить систему
        food_sprites.draw(self.screen)
        bad_sprites.draw(self.screen)
        snake_body_sprites.draw(self.screen)
        batery_sprites.draw(self.screen)
        luck_sprites.draw(self.screen)
        snake_head_sprites.draw(self.screen)
        snake_tail_sprites.draw(self.screen)

        self.objects.render(self.screen)

    # функция постановки на паузу
    def switch_pause(self):
        pygame.time.set_timer(TIMER_EVENT_TYPE, self.hero.delay if not self.hero.is_paused else 0)
        print('пауза')

    # функция, которая запускает рендер змеи (snake.render())
    def relocation(self):
        old_x, old_y = self.hero.get_cords()
        self.hero.move()

        # если змея сдвинулась
        if old_x != self.hero.x or old_y != self.hero.y:
            # обновляем
            self.hero.render()

    # функция для обновления змеи
    def update_hero(self, event):
        # если игра не на паузе
        if not self.hero.is_paused:
            # если нажали на кнопку
            if event.type == pygame.KEYDOWN:
                # обновляем флаг начала игры
                self.hero.start = True

                # если нажата клавиша 'влево' меняем направление змейки, аналогично меняем направление ниже
                if event.key == pygame.K_LEFT:
                    # меняем скорость
                    self.hero.change_speed(-self.hero.snake_speed, 0, False)

                # если нажата клавиша 'вправо'
                elif event.key == pygame.K_RIGHT:
                    # меняем скорость
                    self.hero.change_speed(self.hero.snake_speed, 0, False)

                # если нажата клавиша 'вверх'
                elif event.key == pygame.K_UP:
                    # меняем скорость
                    self.hero.change_speed(0, -self.hero.snake_speed, False)

                # если нажата клавиша 'вниз'
                elif event.key == pygame.K_DOWN:
                    # меняем скорость
                    self.hero.change_speed(0, self.hero.snake_speed, False)

            # пытаемся сдвинуть змею
            self.relocation()

            # если буст скорости активен <= 10 секунд, сдвигаем змею еще на 1 позицию
            if self.hero.speed_boost_active:
                if abs(self.hero.time_speed_boosted - time.time()) <= 10:
                    self.relocation()
                else:
                    self.hero.speed_boost_active = False

    # сохраняет атрибуты классов для загрузки спрайтов
    def save_objects(self, mas):
        save_mas = []
        for el in mas:
            pre = []
            pre.append((el.rect.x, el.rect.y))
            if hasattr(el, 'way'):
                pre.append(el.way)
            if hasattr(el, 'score'):
                pre.append(el.score)
            if hasattr(el, 'health'):
                pre.append(el.health)
            save_mas.append(pre)
        return save_mas

    # сохранение игры
    def save_game(self):
        if not self.hero.is_paused:
            save_data = dict()
            self.hero.load_save = True

            save_data['snake_head_sprites'] = self.save_objects(snake_head_sprites.sprites())
            save_data['food_sprites'] = self.save_objects(food_sprites.sprites())
            save_data['bad_sprites'] = self.save_objects(bad_sprites.sprites())
            save_data['snake_body_sprites'] = self.save_objects(snake_body_sprites.sprites())
            save_data['snake_tail_sprites'] = self.save_objects(snake_tail_sprites.sprites())
            save_data['luck_sprites'] = self.save_objects(luck_sprites.sprites())
            save_data['batery_sprites'] = self.save_objects(batery_sprites.sprites())

            snake = [self.hero.health, self.hero.score, self.hero.start, self.hero.level, self.hero.x, self.hero.y,
                     self.hero.way, self.hero.speed_boost_active, self.hero.time_speed_boosted, self.hero.x_speed,
                     self.hero.y_speed, self.hero.snake_list, self.hero.win, self.hero.is_game_over, self.hero.voice]
            save_data['snake'] = snake

            with open(f'{DATA_DIR}/save.dat', 'wb') as file:
                pickle.dump(save_data, file)

    # загрузка игры
    def load_game(self):
        with open(f'{DATA_DIR}/save.dat', 'rb') as file:
            save_data = pickle.load(file)

        # загружаем змею
        self.hero.health = save_data['snake'][0]
        self.hero.score = save_data['snake'][1]
        self.hero.start = save_data['snake'][2]
        self.hero.level = save_data['snake'][3]
        self.hero.x = save_data['snake'][4]
        self.hero.y = save_data['snake'][5]
        self.hero.way = save_data['snake'][6]
        self.hero.speed_boost_active = save_data['snake'][7]
        self.hero.time_speed_boosted = save_data['snake'][8]
        self.hero.x_speed = save_data['snake'][9]
        self.hero.y_speed = save_data['snake'][10]
        self.hero.snake_list = save_data['snake'][11]
        self.hero.win = save_data['snake'][12]
        self.hero.is_game_over = save_data['snake'][13]
        self.hero.voice = save_data['snake'][14]

        self.hero.head.kill()
        self.hero.tail.kill()

        for i in all_sprites.sprites():
            i.kill()

        # загружаем тело
        for el in save_data['snake_body_sprites']:
            Body(el[0], el[1], el[2], el[3])

        # загружаем голову
        for el in save_data['snake_head_sprites']:
            Head(el[0], el[1], el[2], el[3])

        # загружаем хвост
        for el in save_data['snake_tail_sprites']:
            Tail(el[0], el[1], el[2], el[3])

        # обновляем голову и хвост змеи
        self.hero.head = snake_head_sprites.sprites()[-1]
        self.hero.tail = snake_tail_sprites.sprites()[-1]

        # загружаем BadFood
        for el in save_data['bad_sprites']:
            BadFood(el[0])

        # загружаем GoodFood
        for el in save_data['food_sprites']:
            GoodFood(el[0])

        # загружаем лакиблок
        for el in save_data['luck_sprites']:
            Luck(el[0])

        # загружаем батарейку
        for el in save_data['batery_sprites']:
            Batery(el[0])

        # self.board = Board(self.hero.level)
        # self.board.render(self.screen)
