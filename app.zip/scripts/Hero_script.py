import pygame

from Sprite_script import *


# класс змеи
class Snake:
    def __init__(self):

        # уровень громкости музыки
        self.voice = 0.5

        # зададим здоровье змеи и количество очков
        self.health = 3
        self.score = 0

        # делаем задержку, чтобы змейка ползала с нужной скоростью
        self.delay = 100
        pygame.time.set_timer(TIMER_EVENT_TYPE, self.delay)

        # создадим флаги
        self.start = False
        self.update_level = False
        self.win = False
        self.is_game_over = False
        self.is_paused = False
        self.load_save = False

        # зададим уровень игры и размер границ поля
        self.level = 1

        # ее координаты
        self.x = ((WINDOW_WIDTH // TILE_SIZE) - 2) // 2
        self.y = ((WINDOW_HEIGHT // TILE_SIZE) - 2) // 2

        # направление движения (при спавне голова смотрит вверх)
        self.way = 'u'

        # ее начальную скорость
        self.snake_speed = 1
        self.speed_boost_active = False
        self.time_speed_boosted = time.time()

        # скорость по х в данный момент
        self.x_speed = 0
        # скорость по y в данный момент
        self.y_speed = 0

        # добавляем в группу спрайтов тела 2 элемента - голову и хвост
        self.snake_list = [[self.x, self.y + 2, self.way],
                           [self.x, self.y + 1, self.way],
                           [self.x, self.y, self.way],
                           [self.x, self.y + 3, self.way]]

        # начальное положение змейки, порядок важен, т.к. спрайты добавляются только в конец списка группы!
        Body((self.x, self.y + 2), self.way, self.score, self.health)
        Body((self.x, self.y + 1), self.way, self.score, self.health)
        self.head = Head((self.x, self.y), self.way, self.score, self.health)
        self.tail = Tail((self.x, self.y + 3), self.way, self.score, self.health)

    # функция ДВИЖЕНИЯ!!! добавления сегмента тела змеи (увеличение длины)
    def render(self):
        sprite_list = snake_body_sprites.sprites()
        Body((self.snake_list[-2][:2]), self.snake_list[-2][2], self.score, self.health)  # старая голова --> тело
        # новая голова
        self.head.kill()
        self.snake_list.append([self.x,
                                self.y,
                                self.way])
        self.head = Head((self.snake_list[-1][:2]), self.snake_list[-1][2], self.score, self.health)
        self.head.update()

        # если что-то съели обновляем параметры
        self.health = self.head.health
        self.score = self.head.score
        self.is_game_over = not self.head.is_game

        # изменяем флаг буста скорости
        if self.head.speed_boost:
            self.speed_boost_active = True
            self.time_speed_boosted = time.time()
        elif abs(self.time_speed_boosted - time.time()) > 10:
            self.speed_boost_active = False

        del self.snake_list[-2]  # удаляем из массива змеи (snake_list) старый хвост
        self.snake_list.append([self.tail.rect.x // TILE_SIZE, self.tail.rect.y // TILE_SIZE,
                                self.tail.way])  # добавляем хвост в конец

        if self.score < len(self.snake_list) - 4:
            # двигаем хвост, порядок важен, т.к. спрайты в список группы(sprite_list) добавляются в конец!
            # нужно будет учитывать при увеличении длинны (изначально порядок B-B-H-T)
            self.tail.kill()
            sprite_list[0].kill()
            del self.snake_list[-1]  # удаляем старый хвост
            self.tail = Tail((self.snake_list[0][:2]), self.snake_list[1][2], self.score, self.health)
            self.snake_list.append(self.snake_list[0])  # запоминаем последний сегмент тела как хвост
            del self.snake_list[0]  # удаляем лишний сегмент тела

    # функция изменения скорости змейки
    def change_speed(self, x_speed, y_speed, fl):
        self.x_speed = x_speed
        self.y_speed = y_speed
        # меняем направление в зависимости от скорости
        if self.x_speed == 1:
            self.way = 'r'
        elif self.x_speed == -1:
            self.way = 'l'
        elif self.y_speed == 1:
            self.way = 'd'
        elif self.y_speed == -1:
            self.way = 'u'

        if fl:
            self.snake_speed = 1

    # функция для изменения координат змеи
    def move(self):
        self.x += self.x_speed
        self.y += self.y_speed

    # функция для определения координат змеи
    def get_cords(self):
        return self.x, self.y

    # функция для надписи на экране
    def show_text(self, text, position, size, font_color, screen):
        # зададим параметры шрифта
        font = pygame.font.Font('../Unicephalon/unicephalon.ttf', size)

        # зададим параметры надписи
        t = font.render(text, 1, font_color)

        # выводим на экран
        screen.blit(t, position)
