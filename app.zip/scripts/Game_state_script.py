import pygame
from Sprite_script import *


class State:
    def __init__(self, snake, game):
        self.snake = snake
        self.game = game

    def terminate(self):
        pygame.quit()
        sys.exit()

    def start_screen(self):
        # создаем экран, на котором будут отображаться правила
        pre_screen = pygame.display.set_mode(WINDOW_SIZE)

        with open('history.txt', 'r', encoding='utf-8') as file:
            rules = file.readlines()
            rules = [line.strip() for line in rules]

        fon = pygame.transform.scale(pygame.image.load('../pictures/начало.jpg'), WINDOW_SIZE)
        pre_screen.blit(fon, (0, 0))

        font = pygame.font.Font(None, 30)
        text_coord = 50
        for line in rules:
            string_rendered = font.render(line, 1, pygame.Color('black'))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 10
            text_coord += intro_rect.height
            pre_screen.blit(string_rendered, intro_rect)

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.terminate()
                elif event.type == pygame.KEYDOWN or \
                        event.type == pygame.MOUSEBUTTONDOWN:
                    return  # начинаем игру
            pygame.display.flip()
