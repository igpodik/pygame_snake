with open('level_4.txt', 'r') as file:
    with open('level_4n.txt', 'w') as n:
        ln = 0
        new_l = ""
        for line in file.readlines():
            ln = len(line) - 1
            for i in range(ln):
                new_l += line[i]
                if i != ln:
                    new_l += " "
            new_l += '\n'

        n.write(new_l)
